def areaOfTriangle(b, h):
    return 0.5 * b * h