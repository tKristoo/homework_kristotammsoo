Run triangle_kristotammsoo.py
